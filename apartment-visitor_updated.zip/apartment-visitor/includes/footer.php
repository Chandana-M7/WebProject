<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0.1
    </div>
    Copyright &copy; <?php echo date("Y");?> - Developed By <strong> Naseeb Bajracharya </strong>
  </footer>